import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SolveGameComponent } from './solve-game.component';

describe('SolveGameComponent', () => {
  let component: SolveGameComponent;
  let fixture: ComponentFixture<SolveGameComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SolveGameComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SolveGameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
