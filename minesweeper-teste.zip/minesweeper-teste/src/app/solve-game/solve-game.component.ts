import { Component, OnInit, SecurityContext } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { Bootcamp } from '../camp-definition/bootcamp';

@Component({
  selector: 'app-solve-game',
  templateUrl: './solve-game.component.html',
  styleUrls: ['./solve-game.component.less']
})
export class SolveGameComponent implements OnInit {

  definition = new Bootcamp(5, 5);

  constructor(private domSanitizer: DomSanitizer) { }

  ngOnInit() {


  }

  htmlDisplay(x: number, y: number): SafeHtml {
    return this.domSanitizer.sanitize(SecurityContext.HTML, this.definition.display(x, y).replace(' ', '&nbsp;'));
  }
}
