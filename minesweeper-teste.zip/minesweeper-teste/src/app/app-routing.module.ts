import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CampDefinitionComponent } from './camp-definition/camp-definition.component';
import { SolveGameComponent } from './solve-game/solve-game.component';

const routes: Routes = [
  { path: 'def', component: CampDefinitionComponent },
  { path: 'solve', component: SolveGameComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
