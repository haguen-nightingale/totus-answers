import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CampDefinitionComponent } from './camp-definition/camp-definition.component';
import { SolveGameComponent } from './solve-game/solve-game.component';

import { ThfModule } from '@totvs/thf-ui';

@NgModule({
  declarations: [
    AppComponent,
    CampDefinitionComponent,
    SolveGameComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    ThfModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
